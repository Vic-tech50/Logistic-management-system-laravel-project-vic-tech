<?php echo e($slot); ?>

<?php /**PATH /var/www/html/courier/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>